<?php 

namespace App\FlowDash;

class FlowDash
{
    use AuthorizesRequests;
}
